#-------------------------------------------------#
# Title: Working with Dictionaries
# Dev:   KJarrett
# Date:  April 29, 2018
# ChangeLog:
#   <Kelly Jarrett>, Added code to template to complete assignment 5
#-------------------------------------------------#


"""
1.	Create a text file called Todo.txt using the following data:
    Clean House,low
    Pay Bills,high
2.	When the program starts, load each row of data from the ToDo.txt text file into a Python dictionary.
    (The data will be stored like a row in a table.)
    Tip: You can use a for loop to read a single line of text from the file and then place the data into
    a new dictionary object.
3.	After you get the data in a Python dictionary, Add the new dictionary “row” into a Python list object
    (now the data will be managed as a table).
4.	Display the contents of the List to the user.
5.	Allow the user to Add or Remove tasks from the list using numbered choices. Something like this would work:
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
6.	Save the data from the table into the Todo.txt file when the program exits.

"""

# -- Data --#
# declare variables and constants
dRow1 = {"Task": "Clean house", "Priority": "low"}
dRow2 = {"Task": "Pay bills", "Priority": "high"}
taskTable = [dRow1, dRow2]
print(taskTable)

# objFile = An object that represents a file
objFile = open("C:\\_PythonClass\\Assignment 05\\ToDo.txt", "a")

# Add code that lets users append a new row of data
# Add a loop that lets the user keep adding rows
# Add a menu of options user can choose from
# Allow user to list items in dictionary, add more items, delete item, save to file, exit
while (True):
    strTask = input("Enter a new task:  ")
    strPriority = input("Enter priority (high, medium, low):  ")
    dNewRow = {"Task": strTask, "Priority": strPriority}
    taskTable.append(dNewRow)
    print("""
                Menu of Options
                1) Show current data
                2) Add a new item.
                3) Remove an existing item.
                4) Save Data to File
                5) Exit Program
                """)
    strChoice = str(input("Which option would you like to perform? [1 to 5]:  "))
    if (strChoice.strip() == '1'):
        print(taskTable)
    elif (strChoice.strip() == '2'):
        strTask = input("Enter a new task:  ")
        strPriority = input("Enter priority (high, medium, low):  ")
        dNewRow = {"Task": strTask, "Priority": strPriority}
        taskTable.append(dNewRow)
    elif (strChoice.strip() == '3'):
        deleteItem = input("What item do you want to remove from your tasks:  ")
        if str(deleteItem) in taskTable:
            deletedItems = taskTable.pop(int(deleteItem))
        else:
            print(deleteItem.title() + " is not in your task list.")
    elif (strChoice.strip() == '4'):
        objFile.write(str(taskTable))
        objFile.close()
        print("Your tasks have been save to ToDo.txt.")
    else: break
print("Goodbye")

