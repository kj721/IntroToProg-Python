#-------------------------------------------------#
# Title: Working with classes and functions
# Dev:   KJarrett
# Date:  May 6, 2018
# ChangeLog: (Who, When, What)
#   RRoot, 11/02/2016, Changed the code to match the assignment.
#   Now each row is a dictionary and the table is a list!
#   Using instructor code from assignment 5 as a starting point assignment 6
#   as I had significant issues with my code from assignment #5 code
#https://www.tutorialspoint.com/python/python_dictionary.htm
#-------------------------------------------------#

'''
This project is very like the last one, but this time you will place
the code you created for working with your ToDo.txt file into Functions
and a Class.

'''

# -- Data -- #
# Define variables, files
objFileName = "C:\_PythonClass\Assignment 06\ToDo.txt"
strData = ""
dicRow = {}
lstTable = []

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.
objFile = open(objFileName, "r")
for line in objFile:
    strData = line.split(",") # readline() reads a line of the data into 2 elements
    dicRow = {"Task":strData[0].strip(), "Priority":strData[1].strip()}
    lstTable.append(dicRow)
objFile.close()

# -- Data Processing -- #
# Use class that holds all the functions that the user can choose
# Each function performs one of the choices the user might choose
# First function is to show current tasks
# Second function is to add new tasks
# Third function is to remove tasks
# Fourth function is to save tasks to file
class UserOptions(object):
    @staticmethod
    def ShowCurrentTasks():
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")

    @staticmethod
    def AddNewTasks():
        strTask = str(input("What is the task? - ")).strip()
        strPriority = str(input("What is the priority? [high|low] - ")).strip()
        dicRow = {"Task": strTask, "Priority": strPriority}
        lstTable.append(dicRow)
        print("Current Data in table:")
        for dicRow in lstTable:
            print(dicRow)

    @staticmethod
    def RemoveTasks():
        strKeyToRemove = input("Which TASK would you like removed? - ")
        blnItemRemoved = False  # Creating a boolean Flag
        intRowNumber = 0
        while (intRowNumber < len(lstTable)):
            if (strKeyToRemove == str(
                    list(dict(lstTable[intRowNumber]).values())[0])):  # the values function creates a list!
                del lstTable[intRowNumber]
            blnItemRemoved = True
            # end if
            intRowNumber += 1
        # end for loop
        # 5b-Update user on the status
        if (blnItemRemoved == True):
            print("The task was removed.")
        else:
            print("I'm sorry, but I could not find that task.")

    @staticmethod
    def SaveData():
        print("******* The current items ToDo are: *******")
        for row in lstTable:
            print(row["Task"] + "(" + row["Priority"] + ")")
        print("*******************************************")
        # 5b Ask if they want save that data
        if ("y" == str(input("Save this data to file? (y/n) - ")).strip().lower()):
            objFile = open(objFileName, "w")
            for dicRow in lstTable:
                objFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            objFile.close()
            input("Data saved to file! Press the [Enter] key to return to menu.")
        else:
            input(
                "New data was NOT Saved, but previous data still exists! Press the [Enter] key to return to menu.")
        #continue  # to show the menu

# -- Input/Output -- #
# Step 2
# Display a menu of choices to the user

while(True):

    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 4] - "))
    print()#adding a new line

    # -- Presentation -- #
    if (strChoice.strip() == '1'):
        UserOptions.ShowCurrentTasks()

    elif (strChoice.strip() == '2'):
        UserOptions.AddNewTasks()

    elif (strChoice == '3'):
        UserOptions.RemoveTasks()

    elif (strChoice == '4'):
        UserOptions.SaveData()

    elif (strChoice == '5'):
        break  # and Exit the program

